Para questao 1:
g++ qst1.c linkedList.c


Para questao 2:
g++ qst2.c linkedList.c


Para questao 3:
g++ qst3.c linkedList.c
